import { useState } from 'react'

const asset = (name: string) => `/assets/${name}`

const months = [
  { label: 'Jan', value: 85, active: true },
  { label: 'Feb', value: 90, active: true },
  { label: 'Mar', value: 75, active: true },
  { label: 'Apr', value: 75, active: false },
  { label: 'Mei', value: 75, active: false },
  { label: 'Jun', value: 65, active: false },
  { label: 'Juli', value: 60, active: false },
]

const reportSteps = [
  {
    icon: '6d04f.svg',
    title: 'Tulis masalahnya',
    body: 'Isi 5 langkah singkat. Kira-kira 3 menit.',
  },
  {
    icon: '700da.svg',
    title: 'Simpan kode',
    body: 'Kode ini kunci Anda untuk melihat kabar laporan.',
  },
  {
    icon: 'bf5bf.svg',
    title: 'Cek kabarnya',
    body: 'Kalau petugas bilang sudah beres, Andalah yang menentukan benar atau belum.',
  },
]

function Logo({ footer = false }: { footer?: boolean }) {
  return (
    <a className={`logo ${footer ? 'logo--footer' : ''}`} href="#top" aria-label="PetaPuk home">
      <img src={asset(footer ? 'c0140.svg' : '75842.svg')} alt="" />
      <strong>PetaPuk</strong>
    </a>
  )
}

function App() {
  const [query, setQuery] = useState('')
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [assistantOpen, setAssistantOpen] = useState(false)
  const [reportOpen, setReportOpen] = useState(false)

  const region = query.trim() || 'Nusa Tenggara Barat'

  return (
    <div id="top" className="site-shell">
      <header className="header">
        <Logo />
        <nav className="nav" aria-label="Navigasi utama">
          <img className="nav__shape" src={asset('28de2.svg')} alt="" />
          <a className="nav__active" href="#map">
            <img src={asset('f8bbb.svg')} alt="" />
            <span>PetaData</span>
          </a>
          <a href="#map">Data Wilayah</a>
          <button onClick={() => setReportOpen(true)}>Buat Laporan</button>
          <a href="#reporting">Cek Laporan</a>
          <a href="#distribution">Daftar Subsidi</a>
        </nav>
      </header>

      <main className="dashboard">
        <section id="map" className="map-section" aria-labelledby="map-title">
          <div className="map-toolbar">
            <h1 id="map-title">
              <img src={asset('55929.svg')} alt="" />
              PetaData
            </h1>
            <label className="search">
              <span className="sr-only">Cari wilayah</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Cari Wilayah....."
              />
              <img src={asset('76588.svg')} alt="" />
            </label>
          </div>

          <div className="map-grid">
            <div className="map-frame">
              <img src={asset('a4ad2.png')} alt={`Peta wilayah ${region}`} />
            </div>

            <article className="region-card">
              <img className="region-card__form" src={asset('d2bb4.svg')} alt="" />
              <img className="region-card__line" src={asset('c9f83.svg')} alt="" />
              <div className="region-card__intro">
                <h2>Ringkasan Data Wilayah</h2>
                <p>(point: {region})</p>
              </div>
              <strong className="region-card__percent">80,2%</strong>
              <p className="region-card__caption">Pupuk sudah sampai ke petani</p>
              <div className="stats">
                <div>
                  <span>Jatah Daerah Ini</span>
                  <strong>4,250 ton</strong>
                </div>
                <div>
                  <span>Sudah Disalurkan</span>
                  <strong>3,410 ton</strong>
                </div>
                <div className="stats__alert">
                  <span>Belum Disalurkan</span>
                  <strong>410 ton</strong>
                </div>
              </div>
              <button className="details-button" onClick={() => setDetailsOpen(!detailsOpen)}>
                <img src={asset('a719e.svg')} alt="" />
                {detailsOpen ? 'Tutup Detail' : 'Detail Lengkap'}
              </button>
              {detailsOpen && (
                <div className="detail-popover" role="status">
                  Penyaluran pupuk wilayah {region} telah mencapai 80,2% dari alokasi.
                </div>
              )}
            </article>
          </div>
        </section>

        <div className="lower-grid">
          <section id="distribution" className="chart-card" aria-labelledby="chart-title">
            <h2 id="chart-title">
              <img src={asset('b3b2e.svg')} alt="" />
              Presentase Distribusi Tahunan
            </h2>
            <div className="chart">
              <img className="chart__grid" src={asset('6324b.svg')} alt="" />
              <div className="chart__bars">
                {months.map((month, index) => (
                  <div className="bar-column" key={month.label}>
                    {index === 1 && (
                      <div className="tooltip">
                        Total: 1,000,000
                        <img src={asset('6340a.svg')} alt="" />
                      </div>
                    )}
                    <span className="bar-value">{month.active ? `${month.value}%` : '–'}</span>
                    <span
                      className={`bar ${month.active ? 'bar--active' : ''}`}
                      style={{ height: `${month.value}%` }}
                    />
                    <span className="bar-label">{month.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section id="reporting" className="report-card" aria-labelledby="report-title">
            <h2 id="report-title">
              <img src={asset('5035a.svg')} alt="" />
              Cara Melapor, Mudah
            </h2>
            <div className="step-headings" aria-hidden="true">
              {reportSteps.map((step, index) => (
                <span key={step.title}>
                  {step.title}
                  {index < reportSteps.length - 1 && <img src={asset('36a3b.svg')} alt="" />}
                </span>
              ))}
            </div>
            <div className="steps">
              {reportSteps.map((step, index) => (
                <div className="step" key={step.title}>
                  <img className="step__icon" src={asset(step.icon)} alt="" />
                  <div className="step__bubble">
                    <img src={asset(['c9e09.svg', 'ba8a5.svg', '032a1.svg'][index])} alt="" />
                    <p>{step.body}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="report-button" onClick={() => setReportOpen(true)}>
              <img src={asset('ae2c5.svg')} alt="" />
              Buat Laporan
            </button>
            <img className="report-card__line" src={asset('5dea5.svg')} alt="" />
          </section>
        </div>
      </main>

      <button
        className="assistant-button"
        onClick={() => setAssistantOpen(!assistantOpen)}
        aria-expanded={assistantOpen}
      >
        <span>
          <img className="assistant-button__circle" src={asset('5b6fa.svg')} alt="" />
          <img className="assistant-button__bot" src={asset('1c192.svg')} alt="" />
        </span>
        AI Assistant
      </button>

      {assistantOpen && (
        <aside className="assistant-panel" aria-live="polite">
          <button onClick={() => setAssistantOpen(false)} aria-label="Tutup AI Assistant">
            ×
          </button>
          <strong>Halo, saya asisten PetaPuk.</strong>
          <p>Saya dapat membantu mencari data wilayah atau memandu Anda membuat laporan.</p>
          <button onClick={() => setReportOpen(true)}>Mulai laporan</button>
        </aside>
      )}

      <footer className="footer">
        <div className="footer__inner">
          <div>
            <Logo footer />
            <p>
              Tempat petani mengecek harga resmi dan jatah pupuk subsidi,
              <br /> dan melapor bila ada yang tidak sesuai.
            </p>
          </div>
          <p className="footer__credit">developed by @bisadigantikimpul</p>
          <div className="privacy">
            <img src={asset('f40b0.svg')} alt="" />
            <h2>Privasi Anda</h2>
            <p>
              Tidak perlu akun, nomor KTP, atau nama asli.
              <br /> Nomor HP hanya diisi kalau Anda mau dihubungi.
            </p>
          </div>
        </div>
      </footer>

      {reportOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={() => setReportOpen(false)}>
          <section
            className="report-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <button className="modal-close" onClick={() => setReportOpen(false)} aria-label="Tutup">
              ×
            </button>
            <h2 id="modal-title">Buat Laporan</h2>
            <p>Ceritakan masalah pupuk subsidi di wilayah Anda.</p>
            <label>
              Wilayah
              <input defaultValue={region} />
            </label>
            <label>
              Masalah yang ditemukan
              <textarea placeholder="Tuliskan masalah secara singkat..." rows={4} />
            </label>
            <button className="modal-submit" onClick={() => setReportOpen(false)}>
              Simpan Laporan
            </button>
          </section>
        </div>
      )}
    </div>
  )
}

export default App
